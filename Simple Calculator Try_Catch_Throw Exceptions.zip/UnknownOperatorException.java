
public class UnknownOperatorException extends Exception{
  public UnknownOperatorException(){
    super("You have entered an unknown operator. Only enter operators: + - * /");
  }
  UnknownOperatorException(String m){
    super(m);
  }
}