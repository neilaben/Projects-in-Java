import java.util.*;

public class Calculator{
  public static double Calculate(char operator, double num){
    Scanner scan = new Scanner(System.in);
    double result = 0.0;
    char operators = scan.next().charAt(0);
    double number = scan.nextDouble();

    while(operators == 'r' || operators == 'R'){
      if(operators == '+'){
        result += number;
        System.out.println("result + " + number + " = " + result);
        System.out.println("new result =" + result);
        operators = scan.next().charAt(0);
        number = scan.nextDouble();
      }
      if(operators == '-'){
        result -= number;
        System.out.println("result - " + number + " = " + result);
        System.out.println("new result =" + result);
        operators = scan.next().charAt(0);
        number = scan.nextDouble();
      }
      if(operators == '*'){
        result *= number;
        System.out.println("result * " + number + " = " + result);
        System.out.println("new result =" + result);
        operators = scan.next().charAt(0);
        number = scan.nextDouble();
      }
      if(operators == '/'){
        result /= number;
        System.out.println("result / " + number + " = " + result);
        System.out.println("new result =" + result);
        operators = scan.next().charAt(0);
        number = scan.nextDouble();
      }
    }
    return result;
  } 
}