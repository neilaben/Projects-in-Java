
public class DivisionByZeroException extends Exception {
  public DivisionByZeroException(){
    super("You can't divide by ZERO");
  }
  public DivisionByZeroException(String message){
    super(message);
  }
}