import java.util.*; 

public class Main{
  public static void main(String[] args){
    Scanner scan = new Scanner(System.in);
    double result = 0.0;
    boolean r = false;
    boolean R = false; 

    System.out.println("This calculator only accepts + - / * as operators. \n Enter R or r for the final results. \n\n Calculator is on. \n result = " + result);
    Calculator c1 = new Calculator();

    char operators = scan.next().charAt(0);
    double number = scan.nextDouble();
    c1.Calculate(operators, number);
     try{
      c1.Calculate(operators,number);
      operators = scan.next().charAt(0);
      number = scan.nextDouble();
      if(operators != '+'|| operators != '-'|| operators != '*'|| operators != '/' || operators != 'r' || operators != 'R'){
        throw new  UnknownOperatorException();
      }

     }
     
      if (number==0) {
        throw new DivisionByZeroException();
      }
    
    catch(DivisionByZeroException e){
      System.out.println(e.getMessage());
      System.out.println("Please reenter a number that is not 0");
      
    }
    catch(UnknownOperatorException e){
      System.out.println(e.getMessage());
      }
    
    }
    
  }
