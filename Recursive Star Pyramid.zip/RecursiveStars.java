
public class RecursiveStars{
public static void Printstars(int n){//method to print star pattern based on rows value
    if(n<0){ //used to catch an error if user inputs a negative number 
      Printstars(-1*n); //will call recursively function with positive number of rows
    }
    if(n>=0){ //if rows entered are 0 or positive condition
    for(int i = 0; i < n; i++){ //outer loop for rows
      for(int j = i; j < n-1; j++){ //inner loop for spaces before stars
        System.out.print(" ");
      }
      for(int k = 0; k < i+1; k++){ //inner loop to print stars in a pattern and space after
        System.out.print("*");
        System.out.print(" ");
      }
     System.out.print("\n"); 
    }
  }
}
public static int totalStar(int s){ //method to count total number of pins per pattern
  if(s == 0)
    return 0;
  if(s<0){//catches error if user inputs a negative number, will turn it positive 
    s = -1*s; //turns negative input into a positive
    return s + totalStar(s-1); //returns total pins by calling on itself recursively
  }
  return s + totalStar(s-1);
}
public static int starInfo(int r){//shows total pins as we add rows.
  int result = 0; //result is initialized to zero
  if(r < 0){ //catches user input error if user inputs negative number
    r = -1*r; //changes negative number to positive
    return starInfo(r); //recursively calls on itself as a positive entry
  }
  if(r == 0){ //if input is zero then zero will be returned
    return 0;
  }
  else{
    result = r + starInfo(r-1); //result calculated for total number of pins as rows are added
    System.out.println("If we had only the top " + r + " rows then there would be a total of " + result + " pins."); //
  }
  return result; //returns results

}
}
