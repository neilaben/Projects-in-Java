import java.util.*;
import java.lang.Math; //added to use absolute value

class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("\nEnter the number of rows: \n \nPlease note that negative numbers will be read as positive numbers.");
    int rows = scan.nextInt();
    RecursiveStars R1 = new RecursiveStars(); 
    R1.Printstars(rows); //call printstars method to print the pattern
    System.out.println("\nThere are " + Math.abs(rows) + " rows and a total of " + R1.totalStar(rows) + "\n"); //prints out total number of abs val of rows and corresponding total number of pins in pattern
    R1.starInfo(rows); //calls starinfo to tell you how many total pins in the pattern there are as we add rows
  } 
}