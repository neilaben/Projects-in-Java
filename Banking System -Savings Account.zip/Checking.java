import java.util.*;

public class Checking extends Account{
  public double fee = 1.00;
  public Checking(double balance){
    super(balance);
  }
  public void deposit(double deposit){
    this.balance = this.balance + deposit - fee; 
  }
  public boolean withdraw(double withdraw){
    if(withdraw < 0 && withdraw >= balance){
      System.out.println("Error. Please enter a withdrawl number greater than 0 and less than your current balance. ");
      System.exit(0);
      return false;
    }
    else{
      this.balance = this.balance - withdraw - fee;
      return true;
    }
  }
}
