import java.util.*;

class Main {
  public static void main(String[] args) {
    int option = 0;
    int option2 = 0;
    double deposit = 0.00;
    double initial = 0.00;
    double withdraw = 0.00;
    double balance = 0.00;
    String name; 

    System.out.println("Welcome to the Java Bank.");
    System.out.println("Please choose an option.");
    System.out.println(" 1. Savings Account. \n 2. Checking Account.  \n Enter 3 to exit.");

    Scanner strScan =  new Scanner(System.in);
    Scanner scan = new Scanner(System.in);
    option = scan.nextInt();

      switch(option){
        case 1:
          System.out.print("You want to open a Java Savings Account. Please enter your name: ");
          name = strScan.nextLine();
          System.out.print("You must enter an initial deposit to open your Savings account: ");
          initial = scan.nextInt();
          Savings S1 = new Savings(initial);
          double interest = S1.addInterest();
          System.out.println("Savings Account Balance: " + S1.getBalance());
          System.out.println("\nPlease choose from the following options. \n 1. Deposit into Savings. \n 2. Withdraw from Savings \n 3. Check Savings Balance. \n 4. Return to main menu. \n");
          option2 = scan.nextInt();
            switch(option2){
              case 1: 
                System.out.print("Please enter a Savings deposit amount: ");
                deposit = scan.nextInt();
                S1.deposit(deposit);
                interest = S1.addInterest();
                System.out.println("Savings Account Balance: " + S1.getBalance());
                System.out.println("\nPlease choose from the following options. \n 1. Deposit into Savings. \n 2. Withdraw from Savings \n 3. Check Savings Balance. \n 4. Return to main menu. \n");
                option2 = scan.nextInt();
              case 2:
                System.out.print("Please enter a Savings withdrawl amount: ");
                withdraw = scan.nextInt();
                S1.withdraw(withdraw);
                System.out.println("Savings Account Balance: " + S1.getBalance());
                System.out.println("\nPlease choose from the following options. \n 1. Deposit into Savings. \n 2. Withdraw from Savings \n 3. Check Savings Balance. \n 4. Return to main menu. \n");
                option2 = scan.nextInt();  
              case 3: 
                System.out.println("Savings Account Balance: " + S1.getBalance());
                System.out.println("\nPlease choose from the following options. \n 1. Deposit into Savings. \n 2. Withdraw from Savings \n 3. Check Savings Balance. \n 4. Return to main menu. \n");
                option2 = scan.nextInt(); 
              case 4:
               System.out.println(" 1. Open a Savings Account. \n 2. Open a Checking Account. \n Enter 0 to exit.");
               option = scan.nextInt(); 
            }
          
        case 2:
          System.out.print("You want to open a Java Checking Account. Please enter your name: ");
          name = strScan.nextLine();
          System.out.print("You must enter an initial deposit to open your Checking account: ");
          initial = scan.nextInt();
          Checking C1 = new Checking(initial);
          System.out.println("Checking Account Balance: " + C1.getBalance()); 
          System.out.println("Please choose from the following options. \n 1. Deposit into Checking. \n 2. Withdraw from Checking \n 3. Check Checking Balance. \n 4. Return to main menu. \n");
          option2 = scan.nextInt();
            switch(option2){
              case 1: 
                System.out.print("Please enter a Checking deposit amount: ");
                deposit = scan.nextInt();
                C1.deposit(deposit);
                System.out.println("Checking Account Balance: " + C1.getBalance());
                System.out.println("Please choose from the following options. \n 1. Deposit into Checking. \n 2. Withdraw from Checking \n 3. Check Checking Balance. \n 4. Return to main menu. \n");
                option2 = scan.nextInt();
              case 2:
                System.out.print("Please enter a Checking withdrawl amount: ");
                withdraw = scan.nextInt();
                C1.withdraw(withdraw);
                System.out.println("Checking Account Balance: " + C1.getBalance());
                System.out.println("Please choose from the following options. \n 1. Deposit into Checking. \n 2. Withdraw from Checking \n 3. Check Checking Balance. \n 4. Return to main menu. \n");
                option2 = scan.nextInt();
              case 3:
                System.out.println("Checking Account Balance: " + C1.getBalance());
                System.out.println("Please choose from the following options. \n 1. Deposit into Checking. \n 2. Withdraw from Checking \n 3. Check Checking Balance. \n 4. Return to main menu. \n");
                option2 = scan.nextInt();
              case 4:
               System.out.println(" 1. Open a Savings Account. \n 2. Open a Checking Account. \n Enter 0 to exit.");
               option = scan.nextInt();
            }
          case 3:
            System.out.println("Thank you for banking with Java Bank.");
            System.exit(0);
      }
  }
}