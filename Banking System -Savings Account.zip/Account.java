import java.util.*;

public class Account{
  public double balance;

  public Account(double balance){
    if(balance <= 0.00){
      System.out.println("Balance is at 0.00. Please deposit some money.");
    }
    else{
      this.balance = balance;
    }
  }
  public void deposit(double newdeposit){
    if(newdeposit > 0){
      this.balance += newdeposit; 
    }
    else{
      System.out.println("Please enter an amount greater than zero.");
      System.exit(0);
    }
  }
  public boolean withdraw(double newwithdraw){
    if(balance >= newwithdraw){
      this.balance -= newwithdraw;
      return true;
    }
    else{
      System.out.println("Withdrawl amount exceeds account balance.");
      return false;
    }
  }
  public double getBalance(){
    return balance;
  }
}