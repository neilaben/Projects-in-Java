import java.util.*;

public class Savings extends Account{
  public double interest = 0.01;
  public Savings(double balance){
    super(balance);
  }
  public double addInterest(){
    balance = balance + balance * interest;
    return getBalance();
  }
}