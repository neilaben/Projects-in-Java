import java.util.*;
import java.util.Stack;

class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);

    System.out.print("Please enter a symbol. : ");
    String symbol = scan.nextLine();
    symbol = symbol.replaceAll("\\s",""); //removes any spaces user may have entered
        
    Stack<Character> s = new Stack<>(); //created stack
      for(int i = 0; i < symbol.length(); i++) { //loop to traverse
        if(symbol.charAt(i) == '{' || symbol.charAt(i) == '[' || symbol.charAt(i) == '(') { // if correct symbol is entered it will be entered into the stacked
          s.push(symbol.charAt(i));
        }
        else if(!s.empty() && ((symbol.charAt(i) == ']' && s.peek().equals('[')) || (symbol.charAt(i) == '}' && s.peek().equals('{')) || (symbol.charAt(i) == ')' && s.peek().equals('(')))) { //closing parentheses will lead to a check for its open pair in the stack
          s.pop();
        } 
        else { // if none of the correct symbols are entered then push expression
          s.push(symbol.charAt(i));
        }
      }  
      if(s.empty()) { // if stack is empty it is balanced
        System.out.println("Balanced");
      } 
      else {// if stack is not empty then its pair was not found in the stack or incorrect data type has been entered
        System.out.println("Not Balanced");
      }
  }
}