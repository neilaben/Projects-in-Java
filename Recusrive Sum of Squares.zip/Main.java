import java.util.*;

class Main {
  public static void main(String[] args) {
    System.out.println("Enter a number: ");
    Scanner scan = new Scanner(System.in);
    int y = scan.nextInt();
    int result;
    result=Squares(y);
    System.out.println(result);
  }
  public static int Squares(int x){
    int ans = 0;
    if(x == 1){ 
      return 1;
    }
    else{
      ans = x*x + Squares(x-1);
      return ans;
    }
  }
}