import java.util.*; 


class Main {
  public static double display(Shape shape){ //method to display area of given shape
    double area = shape.area(); 
    return area; 
  }
  public static void main(String[] args) {
    System.out.println("Please enter a number for which shape you would like to calculate the area. \n 1 : Circle \n 2: Rectangle \n 3: Exit"); //menu option for user
    Scanner scan = new Scanner(System.in);
    int select = scan.nextInt(); //input from user for menu option

    do{
      if(select == 1){ //if user selects option 1 the area of circle will be calculated
           System.out.println("Please enter a radius: ");
          double r = scan.nextInt(); //accepts radius from user
          Circle c = new Circle(r); //inputs radius for circle 
          System.out.println("A circle with a radius of " + r + " has an area of " + display(c));

          System.out.println("Would you like to calculate another area? \n 1 : Circle \n 2: Rectangle \n 3: Exit");
            select = scan.nextInt(); //lets user continue in menu as long as they dont want to exit
      }
      if(select == 2){ //if user selects option 2 the area of the rectangle will be calculates
          System.out.println("Please enter a height: ");
          double h = scan.nextInt();
          System.out.println("Please enter a width: ");
          double w = scan.nextInt();

          Rectangle rect = new Rectangle(h,w); //inputs height and width for rectangle 
          System.out.println("A rectangle with a height of "+ h + " and width of " + w + " has an area of " + display(rect));

          System.out.println("Would you like to calculate another area?\n 1 : Circle \n 2: Rectangle \n 3: Exit");
            select = scan.nextInt(); //allows user to continue in menu
        }
      if(select == 3) { //user selects option 3 to exit
          System.out.println("Thank you.");
          System.exit(0);
        }
       if(select > 3){ //catches out of bounds error will give user one more try to enter correct value
          System.out.println("You can only enter these options: \n 1 : Circle \n 2: Rectangle \n 3: Exit");
          select = scan.nextInt();
          if(select <3 && select >= 0) //if user selects another correct value then system will continue
            continue;
          else{
            System.out.println("Restart the program and try again");
            System.exit(0); //system will exit if user enters another incorrect value
          }
        }
      
    }while(select >= 0 );//menu will continue as long as an error or exit request isnt encountered
  }
}