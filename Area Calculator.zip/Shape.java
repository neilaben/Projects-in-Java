public interface Shape{
  public double area(); //area method for shape
}