public class Rectangle implements Shape{
  double height; 
  double width;
  public Rectangle(double height, double width){
    this.height = height; //takes user input
    this.width = width; 
  }
  public double area(){
    return height*width; //returns area of a triangle
  }
}