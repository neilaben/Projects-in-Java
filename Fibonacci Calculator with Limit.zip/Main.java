import java.util.*;

class Main {
  public static Integer evenFibonacciSum(Integer n){ //recursive fib function
    if(n>2){ // if fib limit is greater than 2 we will have a sum > 2
      return evenFibonacciSum(n-1) + evenFibonacciSum(n-2); //recursive funciton call 
    }
    else{ // if fib limit is 2 or less the sum will be 0 or 1
      return n;
    }

  }
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("Enter fibonacci limit: "); //user enters limit
    int limit = scan.nextInt();
    int sum = 0; //set fib sum to 0
    for(int i = 0; ; i++){ //for loop to call recursive function to sum of fibs 
      int value = evenFibonacciSum(i);
      if(value>limit){ // breaks additional fib sum calculations if the limit is reached
        break;
      }
      if(value%2 == 0){ //checks only for even fib values with mod2
        sum += value; //creates new sum with every new qualifying value 
        System.out.print(" + " + value + " "); //shows all values being included in calculation
      }
      
    }
    System.out.println("\nThe sum of all even Fibonacci numbers less than or equal to "+ limit + " is "+sum); //prints final sum for even value for fib limit
  }
}