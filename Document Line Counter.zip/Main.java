import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("Enter source file name please: "); //user input to name their input file
    File file = new File(scan.nextLine());

    try{
      Scanner input = new Scanner(file);
      System.out.println("Enter output file name please: "); //name for output file created
      PrintWriter p = new PrintWriter(scan.nextLine()); //write line by line poem in output file
      String read; 
      int numLine = 1;

      while(input.hasNextLine()){ //read next line as long as ther is a next line
        read = input.nextLine();
        p.println("Line " + numLine + " | " + read); 
        ++numLine;
      }
      p.close();
      input.close();
    }
    catch(FileNotFoundException e){
      System.out.println(file.getAbsolutePath() + "File does not exist."); //file was not input into the system
    }
  }
}