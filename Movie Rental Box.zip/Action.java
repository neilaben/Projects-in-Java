import java.util.*;

public class Action extends Movie{
  public Action(String title, String rating, int ID){
    super(title, rating, ID);
  }
  public double calculateFees(int days){
    return days * 3;
  }
}
