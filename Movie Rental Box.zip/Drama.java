import java.util.*;

public class Drama extends Movie{
  public Drama(String title, String rating, int ID){
    super(title, rating, ID);
  }
  public double calculateFees(int days){
    return days * 2; 
  }
}