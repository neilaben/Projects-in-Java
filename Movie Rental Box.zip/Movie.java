import java.util.*;

public class Movie{
  public String title;
  public String rating; 
  public int ID;

  public Movie(String theTitle, String theRating, int theID){
    title = theTitle;
    ID = theID;
    rating = theRating;
  }
  public String getTitle(){
    return title;
  }
  public String getRating(){
    return rating; 
  }
  public int getID(){
    return ID;
  }
  public boolean equals(Movie other){
    if(other.getID() == ID){
      return true;
    }
    else return false; 
  }
  public double calculateFees(int days){
    return days * 2; 
  }
}