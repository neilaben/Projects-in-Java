import java.util.*;

public class Comedy extends Movie{
  public Comedy(String title, String rating, int ID){
    super(title, rating, ID);
  }
  public double calculateFees(int days){
    return days * 2.5; 
  }
}