import java.util.*;

public class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);

    Movie movies[] = new Movie[10]; //array for movies owned by shop
    movies[0] = new Drama("Titanic", "PG-13", 100);
    movies[1] = new Drama("The Godfather", "R", 101);
    movies[2] = new Drama("Forrest Gump", "PG-13", 102);
    movies[3] = new Action("The Matrix", "R", 200);
    movies[4] = new Action("Gladiator", "R", 201);
    movies[5] = new Action("Terminator", "R", 202);
    movies[6] = new Comedy("Airplane", "PG", 300);
    movies[7] = new Comedy("Monty Python and the Holy Grail", "PG", 301);
    movies[8] = new Comedy("Spaceballs", "PG", 302);
    movies[9] = new Drama("Sinking of the Lusitania", "PG-13", 100); 

  System.out.println("Menu: \n Enter the Number of the option \n 0. Exit \n 1. Check movies with same ID. \n 2. Return a movie.");
  int option = scan.nextInt();
  do{
  if(option == 1){
    for(int i= 0; i < movies.length; i++){
      for(int j = 0; j < movies.length; j++){
        if(i != j && i > j){
          if(movies[i].equals(movies[j])){
            System.out.println(movies[i].getTitle() + " with ID: " + movies[i].getID() +" has the same ID as " + movies[j].getTitle() + " with ID: " + movies[j].getID());
            System.out.println("\nEnter another menu option.");
            option = scan.nextInt();
          }
        }
      }
    }
  }
  if(option == 2){
    System.out.println("How many movies are you returning?");
    int num = scan.nextInt();
    for(int i = 0; i < num; i++){
      System.out.println("What kind of movie are you returning? Enter 1 for Drama, 2 for Action, 3 for Comedy");
      int genre = scan.nextInt();
      System.out.println("How many days late are you returning the movie?");
      int late = scan.nextInt();
        if(genre == 1){
          System.out.println("Late Fee: $" + movies[0].calculateFees(late) + "0");
        }
        if(genre == 2){
          System.out.println("Late Fee: $" + movies[3].calculateFees(late) + "0");
        }
        if(genre == 3){
          System.out.println("Late Fee: $" + movies[6].calculateFees(late) + "0");
        }
    }
    System.out.println("\nEnter another menu option.");
    option = scan.nextInt();
  }
  }while(option != 0);  
  if(option == 0){
    System.out.println("Have a good day.");
    System.exit(1);
  }
  }
}